<?php 
$login=false;
$showerror=false;
if($_SERVER['REQUEST_METHOD']=='POST'){
    
    include 'partial/db_connect.php';
    $email = $_POST["email"];
    $password = $_POST["password"];
    
    
    // $sql = "Select * from registration where username = '$username' && password = '$password'";
    $sql ="select * from registration where email = '$email'";
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);
    if($num==1){
      while($row=mysqli_fetch_assoc($result)){
        if(password_verify($password, $row['password'])){
          $login=true;
          session_start();
          $_SESSION['loggedin']=True;
          $_SESSION['email']=$email;
          header("location: home.php");
          }
      }
        
        
    }
    else{
        $showerror="Invalid Credentials";
    }
    


}

?>