<?php

$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'chatapp';

$conn  = mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    echo '<div class="alert alert-warning col-md-6" role="alert">
    Failed To connect
  </div>'.mysqli_connect_error();
}




?>