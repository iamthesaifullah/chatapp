<?php
$showalert = false;
$showerror = false;
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

  include 'partial/db_connect.php';
  
 
  $email = $_POST["email"];
  $password = $_POST["password"];
 
  // $exists = false;
  

  $existssql = "select * from admin where email = '$email'";
  $result = mysqli_query($conn, $existssql);
  $numexitrows = mysqli_num_rows($result);
  if ($numexitrows > 0) {
    $showerror = "Failed!!! Email already exists";
  } 
  else {

    if ($password){
      $hash = password_hash($password, PASSWORD_ARGON2I);
      $sql = "INSERT INTO `admin` (`email`, `password`) VALUES ('$email', '$hash')";
      $result = mysqli_query($conn, $sql);
      if ($result) {
        
       $showalert = "Successful!!! New admin Added.";
            
      } else {
            $showerror = "Failed!!! Your info given wrong";
      }
    }
  }
}

?>







<?php 


session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin']!=true){
  header("location: admin.php");
  exit;
}




?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
    <style>
    .p {
        position: absolute;
        top: 50%;
        left: 40%;
        color: #fff;
    }
    .d{
        position: absolute;
        top: 60%;
        left: 40%;
    }
    </style>
</head>

<body>
    <?php require 'partial/_nav.php' ?>
    <!-- <button type="button" class="btn btn-outline-success">Success</button> -->

    <!-- slider -->
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img style="height: 600px;" src="https://wallpaperaccess.com/full/1325192.jpg" class="d-block w-100"
                    alt="load...">
                    <div class="container">
                        <h1 class="p">Welcome to Admin Panel</h1>
                        <a href="adminlogout.php" type="button" class="btn btn-success d">Logout As Admin</a>
                </div>
            </div>
        </div>
    </div>
    <!-- slider end -->

    <div class="container">
        <h3 class="text-center mt-1">All User's Informations Action here : </h3>
        <h2></h2>
        <table class="table table-striped table-dark myTable">
            <thead>
                <tr>
                    <th>Sno</th>
                    <th>username</th>
                    <th>email</th>
                    <th>Date</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>




                <tr>
                    <?php
                include 'partial/db_connect.php';
                $sql ="Select * from registration";
                $result = mysqli_query($conn,$sql);
                $i=1;
                while($row=mysqli_fetch_assoc($result)){
                      $sno=$row['sno'];
                      $username=$row['username'];
                      $email=$row['email'];
                      $password=$row['password'];
                      $dt=$row['dt'];
                
                        echo '<td>'.$i.'</td>
                        <td>'.$username.'</td>
                        <td>'.$email.'</td>
                        <td>'.$dt.'</td>
                  
                        <td><a href="update.php?rn='.$sno.'&username='.$username.'&email='.$email.'&password='.$password.'"><button class="btn btn-primary">Edit</button></a></td>
                        <td><a href="delete.php?rn='.$sno.'"><button class="btn btn-primary">Delete</button></a></td>
                      </tr>';
                      $i++;
        }
    
        ?>



            </tbody>
        </table>
        <hr>
    </div>
    <!-- admin add -->

    <div class="container">
        <h3 class="text-center mt-1">All Rooms Informations Action here : </h3>
        <h2></h2>
        <table id="myTable" class="table table-striped table-dark myTable">
            <thead>
                <tr>
                    <th>Sno</th>
                    <th>Room Name</th>

                    <th>Date</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>




                <tr>
                    <?php
        include 'partial/db_connect.php';
        $sql ="Select * from rooms";
        $result = mysqli_query($conn,$sql);
        $i=1;
        while($row=mysqli_fetch_assoc($result)){
              $sno=$row['sno'];
              $roomname=$row['roomname'];
              $stime=$row['stime'];
        
                echo '<td>'.$i.'</td>
                <td>'.$roomname.'</td>
                <td>'.$stime.'</td>
          
                <td><a href="roomupdate.php?rn='.$sno.'&roomname='.$roomname.'"><button class="btn btn-primary">Edit</button></a></td>
                <td><a href="roomdelete.php?rn='.$sno.'"><button class="btn btn-primary">Delete</button></a></td>
              </tr>';
              $i++;
        }
    
        ?>



            </tbody>
        </table>
        <hr>
    </div>



    <!-- safhas -->

    <div class="container">
        <h3 class="text-center mt-1">All msg Informations Action here : </h3>
        <h2></h2>
        <table id="myTable" class="table table-striped table-dark myTable">
            <thead>
                <tr>
                    <th>Sno</th>
                    <th>Message</th>
                    <th>Ip</th>
                    <th>Room</th>
                    <th>Time</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>




                <tr>
                    <?php
        include 'partial/db_connect.php';
        $sql ="Select * from msgs";
        $result = mysqli_query($conn,$sql);
        $i=1;
        while($row=mysqli_fetch_assoc($result)){
              $sno=$row['sno'];
              $msg=$row['msg'];
              $ip=$row['ip'];
              $time=$row['stime'];
              $room=$row['room'];
        
                echo '<td>'.$sno.'</td>
                <td>'.$msg.'</td>
                <td>'.$ip.'</td>
                <td>'.$room.'</td>
                <td>'.$time.'</td>
                <td><a href="update.php?rn='.$sno.'&fn='.$ip.'&email='.$time.'&date='.$room.'"><button class="btn btn-primary">Edit</button></a></td>
                <td><a href="msgdelete.php?rn='.$sno.'"><button class="btn btn-primary">Delete</button></a></td>
              </tr>';
              $i++;
        }
    
        ?>



            </tbody>
        </table>
        <hr>
    </div>
    <!-- sdfjahasdf -->
    <div class="container">
        <!-- alerts  -->
        <?php 
if($showalert){
    echo'<div class="alert alert-info alert-dismissible fade show" role="alert">
    <strong>'.$showalert.'</strong> 
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}
if($showerror){
    echo'<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <strong>'.$showerror.'</strong> 
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>';
}

?>
        <!-- alerts end -->
        <h3 class="text-center">Add New Admin</h3>
        <form action="/chatapp/dashboard.php" method="post">
            <div class="mb-3 col-md-6">
                <label for="exampleInputEmail1" class="form-label">Email address</label>
                <input type="email" name="email" class="form-control" id="exampleInputEmail1"
                    aria-describedby="emailHelp">
                <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
            </div>
            <div class="mb-3 col-md-6">
                <label for="exampleInputPassword1" class="form-label">Password</label>
                <input type="password" name="password" class="form-control" id="exampleInputPassword1">
            </div>
            <div class="mb-3 col-md-6 form-check">
                <input type="checkbox" class="form-check-input" id="exampleCheck1">
                <label class="form-check-label" for="exampleCheck1">Check me out</label>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

    </div>
    <!-- admin  add end  -->





    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        $('.myTable').DataTable();
    });
    </script>
</body>

</html>