<?php

$room = $_POST['room'];

if(strlen($room)>30 or strlen($room)<4)
{
	$message = "please input 4 to 30 characters more than is not valid";
	echo '<script language="javascript">';
	echo 'alert("'.$message.'");';
	echo 'window.location = "http://localhost/chatapp/home.php";';
	echo '</script>';
}
elseif (!ctype_alnum($room)) {
	# code...
	$message = "please input 4 to 30 characters more alphanumeric name";
	echo '<script language="javascript">';
	echo 'alert("'.$message.'");';
	echo 'window.location = "http://localhost/chatapp/home.php";';
	echo '</script>';
}
else{
	# connect with database
	include 'db_connect.php';

}

$sql = "SELECT * FROM `rooms` WHERE roomname='$room'";
$result = mysqli_query($conn, $sql);

if ($result) {
	if (mysqli_num_rows($result)>0) 
	{
		$message = "The room already exist try different name";
		echo '<script language="javascript">';
		echo 'alert("'.$message.'");';
		echo 'window.location = "http://localhost/chatapp/home.php";';
		echo '</script>';
	}
	else {
		$sql = "INSERT INTO `rooms` (`roomname`, `stime`) VALUES ('$room', current_timestamp());";
		if (mysqli_query($conn, $sql)) {
			$message = "Your Chat room is ready now go and chat";
			echo '<script language="javascript">';
			echo 'alert("'.$message.'");';
			echo 'window.location = "http://localhost/chatapp/rooms.php?roomname=' .$room.'";';
			echo '</script>';
		}
	}
}
echo "error".mysqli_error($conn);

?>