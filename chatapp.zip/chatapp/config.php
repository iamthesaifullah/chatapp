<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "chatapp";

$conn = mysqli_connect($servername, $username, $password, $dbname);
$name = $_POST['name'];
$pass = $_POST['pass'];
$s = " select * from login where username = '$name' && password = '$pass' ";
$result = mysqli_query($conn, $s);

$num = mysqli_num_rows($result);

if($num == 1){
   echo "login successful";
   header('location:login.php');
}
else{
   header('location:index.php');
}


?>