<?php
include 'partial/db_connect.php';
session_start();
unset($_SESSION["loggedin"]);
unset($_SESSION["email"]);
header("Location:admin.php");
?>