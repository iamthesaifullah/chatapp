-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2021 at 07:48 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chatapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `sno` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`sno`, `email`, `password`) VALUES
(1, 'nriobsaifullah@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$RE9VZFRCSWx3SVduZ1NOWA$UIMAOvoaJOji9nege6IREXvKo0jEer4vaSSYGPxJ6QY'),
(3, 'nazmul.shishir75@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$ZG93Ylo0NXVxTW5TdXlwcw$i5NHoZvAprXcCGw+UnuL8tLdYWA9nqwPD7Aukkitzbg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `sno` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `pass` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`sno`, `name`, `pass`) VALUES
(1, 'saiful', 'iloveyoutrisha');

-- --------------------------------------------------------

--
-- Table structure for table `msgs`
--

CREATE TABLE `msgs` (
  `sno` int(11) NOT NULL,
  `msg` text NOT NULL,
  `room` text NOT NULL,
  `ip` text NOT NULL,
  `stime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `msgs`
--

INSERT INTO `msgs` (`sno`, `msg`, `room`, `ip`, `stime`) VALUES
(1, 'hsdfui', '', '0', '2021-03-31 12:59:09'),
(33, 'hi', 'SaifullahTanim', '0', '2021-05-09 03:13:17'),
(34, 'hello', 'SaifullahTanim', '0', '2021-05-09 03:17:25'),
(35, 'hi there', 'SaifullahTanim', '0', '2021-05-09 03:18:21'),
(36, 'hi there', 'SaifullahTanim1', '0', '2021-06-29 21:51:25'),
(37, 'kire nosto', 'SaifullahTanim1', '0', '2021-06-29 21:51:42'),
(38, 'hi ami nazmul ', 'nazmulthefunda', '0', '2021-06-29 21:55:59'),
(39, 'ami saiful', 'nazmulthefunda', '0', '2021-06-29 21:56:12'),
(40, 'hi there', 'nazu1', '0', '2021-06-30 20:54:05'),
(42, 'hi there', 'sdfsadfasdf', '0', '2021-06-30 22:00:20'),
(43, 'hi there', 'sammmasasa', '0', '2021-07-01 23:54:12'),
(44, 'hi there', 'SaifullahTanimggg', '0', '2021-07-03 23:29:22'),
(45, 'hi harami', 'SaifullahTanimggg', '::1', '2021-07-03 23:36:04'),
(46, 'hi there', 'dsfsdfasdfsad', '::1', '2021-07-04 00:11:29'),
(47, 'hi there', 'saifulkingking', '::1', '2021-07-04 00:23:28'),
(48, 'hi there', 'samma124', '::1', '2021-07-04 00:32:32'),
(49, 'hi', 'dbmsproject5664', '::1', '2021-07-31 23:34:27'),
(50, 'hi there', 'saiftheking', '::1', '2021-08-03 21:30:09'),
(51, '', 'saiffskdfjasfdsdf', '::1', '2021-08-03 21:40:17'),
(52, 'hi there', 'saiffskdfjasfdsdf', '::1', '2021-08-03 21:40:23'),
(53, 'hi there foinny nazmul', 'wearedream', '::1', '2021-08-03 22:53:27'),
(54, 'sdgasdg', 'sdfasdf4', '::1', '2021-08-09 00:37:40'),
(55, 'hi there i am saifullah', 'SaifullahTanim8', '::1', '2021-08-09 00:53:20'),
(56, 'saiful kemon achos?', 'SaifullahTanim8', '::1', '2021-08-09 00:55:20'),
(57, 'hi', 'saffu1245', '::1', '2021-08-09 11:19:40'),
(58, 'hello there', 'saffu1245', '::1', '2021-08-09 11:19:47');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `sno` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(300) NOT NULL,
  `dt` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`sno`, `username`, `email`, `password`, `dt`) VALUES
(20, 'farha', '123@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$d2IuLzF5SzNxSDhYTlMwMw$c3KpsiA fDQIp0/hRt0Ed cTirb 2ejwueinPQKnKRI', '2021-07-02 00:34:24'),
(21, 'mahmood2', 'sishir@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$a2U1dHd3WXhacVVvb1AzYg$DhDYz/Bfdy8b7jfY5AWgeZ jrQlrt7Pa4mm1d4VXmWw', '2021-07-02 00:35:53'),
(22, 'tanimvai', 'nriobsaifullah@gmail.com', 'saifullah12', '2021-07-02 00:47:20'),
(24, 'eagantuk', 'eagantuks@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$eU9SNWcvUWliSC8yMW1KaA$ESUq6uczCaDNmHrJgVjWROEb7zTYhOMwu66CF3HQuXg', '2021-07-04 00:35:07'),
(25, 'mahmoodss', 'kaisarsaiful@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$RE9VZFRCSWx3SVduZ1NOWA$UIMAOvoaJOji9nege6IREXvKo0jEer4vaSSYGPxJ6QY', '2021-07-31 20:28:56'),
(27, 'mahmudsaif', 'mahmudsaif@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$OS55SEhQNUJIM2RmU1hjWg$EiGyZ52d3CDuOiUfDAalNQe+fsSMX59BIESBcAzwYhg', '2021-08-03 21:14:44'),
(28, 'taniv2', 'taniv@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$U09RUC9YRHBVc1pOVUJrQw$xWPfwimOd/R/x52eCgOKUHkq8T4vS4EeFs4voPUT6TY', '2021-08-03 22:51:01'),
(29, 'tanimhasan', 'taniv5@gmail.com', '$argon2i$v=19$m=65536,t=4,p=1$TlpScGtkeVMxbkhTZUx3Mw$UsbBzDFzMdt4DwTHVW/3JU8Us9jTgGX4TpxUUaDXA78', '2021-08-09 11:19:15');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `sno` int(11) NOT NULL,
  `roomname` text NOT NULL,
  `stime` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`sno`, `roomname`, `stime`) VALUES
(1, '1', '2021-03-30 17:12:48'),
(3, 'safii', '2021-03-30 17:23:48'),
(4, 'saifullah', '2021-03-30 17:32:20'),
(5, 'sadfas', '2021-03-30 17:35:06'),
(6, 'samma', '2021-03-30 17:38:29'),
(7, 'safffu', '2021-03-30 17:46:26'),
(8, 'saddas', '2021-03-31 12:52:22'),
(10, 'saifultrisha', '2021-05-03 22:46:53'),
(12, 'samaf', '2021-05-04 00:35:21'),
(13, 'saffu4564', '2021-05-04 00:57:41'),
(14, 'saifullah25', '2021-05-06 20:39:44'),
(15, 'fdsafsd', '2021-05-09 01:46:28'),
(16, 'amitanimvai', '2021-05-09 02:44:42'),
(17, 'saifullah1', '2021-05-09 03:00:48'),
(18, 'SaifullahTanim', '2021-05-09 03:12:02'),
(19, 'SaifullahTanim1', '2021-06-29 21:51:18'),
(20, 'nazmulthefunda', '2021-06-29 21:55:27'),
(21, 'nazu1', '2021-06-30 20:53:55'),
(22, 'sammmmma', '2021-06-30 21:41:03'),
(23, 'sdfsadfasdf', '2021-06-30 21:59:24'),
(24, 'sammmasasa', '2021-07-01 23:54:04'),
(25, 'SaifullahTanimggg', '2021-07-03 23:29:14'),
(26, 'safiidfgdfg', '2021-07-04 00:06:05'),
(27, 'dsfsdfasdfsad', '2021-07-04 00:09:23'),
(28, 'dbmsproject', '2021-07-04 00:22:24'),
(29, 'saifulkingking', '2021-07-04 00:23:21'),
(30, 'samma124', '2021-07-04 00:32:27'),
(31, 'dbmsproject5664', '2021-07-31 23:34:21'),
(32, 'saiftheking', '2021-08-03 21:30:01'),
(33, 'saiffskdfjasfdsdf', '2021-08-03 21:38:27'),
(34, 'sammmas45', '2021-08-03 22:14:13'),
(35, 'wearedream', '2021-08-03 22:51:27'),
(36, 'sdfasdf4', '2021-08-09 00:37:32'),
(37, 'SaifullahTanim8', '2021-08-09 00:50:49'),
(38, 'saffu1245', '2021-08-09 11:18:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `msgs`
--
ALTER TABLE `msgs`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`sno`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `msgs`
--
ALTER TABLE `msgs`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
