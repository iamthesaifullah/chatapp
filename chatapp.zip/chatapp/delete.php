<?php

include 'partial/db_connect.php';

$rn=$_GET['rn'];

include 'partial/db_connect.php';
$sql ="Delete from registration where sno = '$rn'";
$result = mysqli_query($conn,$sql);

if(!$result){
    echo "Record was not deleted".mysqli_error($conn);
}
else{
    header("location: dashboard.php");
}







?>